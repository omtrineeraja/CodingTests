export class CurrencyRate{
    
    currency:string;
    rate:number;

    constructor(instance = {}) {
        Object.assign(this, instance);
      }

  
}