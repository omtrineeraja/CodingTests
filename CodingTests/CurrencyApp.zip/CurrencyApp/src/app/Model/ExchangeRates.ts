import {CurrencyRate} from './CurrencyRate';

export class ExchangeRate {
   public base:string;
   public date:string;
   private _rates:CurrencyRate;

   constructor(instance = {}) {
    Object.assign(this, instance);
  }


   set Rates(val) {
    this._rates = new CurrencyRate(val);
  }
  get Rates(): CurrencyRate {
    return this._rates;
  } 

  
}

