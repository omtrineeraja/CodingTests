import { Component, OnInit } from '@angular/core';
import {CurrencyService} from '../Services/currency.service';
import {ExchangeRate} from '../Model/ExchangeRates';
import {CurrencyRate} from '../Model/CurrencyRate'


@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {
  
  id_currency: string = "";
  my_result: any;
  rates:CurrencyRate[];

  constructor(private currencyService: CurrencyService) {
  }

  ngOnInit() {
  }

 
  callCurrencyService() {  
    this.currencyService.getCurrencyExchRate(this.id_currency.toUpperCase())
      .subscribe(
        resp => {
          this.my_result = resp as ExchangeRate;
          console.log(this.my_result.rates);    
          //this.UpdateRoutes();
        }
      ),
      error => {
        console.log("Error. The callCurrencyService result JSON value is as follows:");
        console.log(error);
      }; 
  }

  ParseData(ExchangeRate)
  {}
}
