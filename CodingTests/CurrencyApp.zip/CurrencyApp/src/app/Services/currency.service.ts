import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ExchangeRate } from '../Model/ExchangeRates';

@Injectable({
  providedIn: 'root'
})
export class CurrencyService {

  constructor(private http:Http) { }

  currencyURL = " https://exchangeratesapi.io/api/latest?base="; 

  currencies:string[] = ["USD","GBP","EUR","AUD"];

  getCurrencies() :string[] 
  {
    return this.currencies;
  }

   getCurrencyExchRate(currency) { 

   return this.http.get(this.currencyURL + currency)
         .map((res: Response) => res.json())
       .catch(error => Observable.throw(error.json()));
   }
}
