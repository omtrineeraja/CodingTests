import { Component } from '@angular/core';
import {CurrencyService} from './Services/currency.service';
import {ExchangeRate} from './Model/ExchangeRates';
import { Http, Response} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CurrencyApp';
}
